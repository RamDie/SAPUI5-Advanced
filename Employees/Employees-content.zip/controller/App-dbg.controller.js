sap.ui.define([
    "sap/ui/core/mvc/Controller"
], function (Controller) {
    return Controller.extend("logaligroup.Employees.controller.App", {
        onInit: function () {

        }
    });
});